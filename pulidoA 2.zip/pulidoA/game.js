//Minesweeper
//Angel

var grid;
var cols;
var rows;
var w = 20;
var h = 20;

function make2DArray(cols, rows) {
    var arr = new Array(cols);
    for(var i = 0; i < arr.length; i++){
        arr[i] = new Array(rows);
    }
    
        //begin for loop here
        return arr;
    }
    
    
function setup()
{
    createCanvas (200, 200);
    cols = floor(width / h);
    rows = floor(height / w);
    
    
    grid = make2DArray(cols, rows);
    for(var i = 0; i < cols; i++)
    {
        for (var j = 0; j <rows; j++)
        {
            grid[i][j] = new Cell(i*h, j*w, w, h);
        }        
    }    
}

function draw()
{
    background(0);
    for (var i = 0; i <cols; i++)
    {
        for (var j = 0; j <rows; j++)
        {
            grid[i][j].show();
        }
    } 
}