print "How old are you?", 
age = 15 
print "How tall are you?",
height = 5,7
print "How much do you weigh?",
weight = 150

print "So you're %r old, %r tall and %r heavy" % (
    age , height, weight,)