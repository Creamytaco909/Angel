import time
def CountUp(stop):
    count = 0
    while (count <= stop):
        time.sleep(5)
        print count
        count = count + 1
        
CountUp(15)
print "I hate jesus"