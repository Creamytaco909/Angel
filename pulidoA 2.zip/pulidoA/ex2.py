# Acomment, this is so you can read your program later.
# Anything after the # is ignored ny python.

print "i could have code like this." # and the comment after this is ignored

# you can also use a comment to "disable" or comment out of place of code:
#print "This won't run."

print "this will run."