function Cell(x, y, w, h)
{
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.bee = true;
    this.revealed = true;
}

Cell.prototype.show = function()
{
    rect(this.x, this.y, this.w, this.h);
}