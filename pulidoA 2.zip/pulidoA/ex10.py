tabby_cat = "\tI'm  tabbed in."
persian_cat = "I'm split\non a line."
blacklash_cat = "I',m \\ a \\ cat."

fat_cat = """
I'll do a list:
\t* cat food
\t* fishies
\t* cat nip\n\t* Grass
"""

print tabby_cat
print persian_cat
print blacklash_cat
print fat_cat