def sortList (aList, reverse):
    
    sample output
    
aList = []