from sys import argv

script, first, second , third = argv

print "The script is called:", script
print "Your first variable is:", first 
print "your second variable is:", second
print "your third  variabe is:", third