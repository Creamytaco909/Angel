from sys import argv

script, abel = argv
promt = '?'

print "Hi %s, I'm the %s script." % (abel, script)
print "I'd like to ask you a few questions."
print "Do you like me %s?" % abel
likes = raw_input('?')

print "Where do you live %s?" % abel
lives = raw_input('?')

print "what kind of computer do you have?"
computer = raw_input('?')

print """
Alright, so you said %r liking me.
you live in %r. Not sure where that is.
And you have a %r computer. Nice 
""" % (likes, lives, computer)