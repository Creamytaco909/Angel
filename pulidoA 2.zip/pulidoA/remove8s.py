a=[1,6,7,8,]
b=[8,1,2,3,]
c=[1,2,3,4]
d=[1,-8,-8,-1,8,1,8,1,8,8]
e=[4,2,3]

def remove8s(alist):
    end = len(alist) -1
    while(c <= end):
        if (alist[c] == 8)
        
    